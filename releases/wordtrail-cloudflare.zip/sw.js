/* Wordtrail offline worker. Generated from the complete production build. */
const VERSION = "4ae8d99df20541d9";
const CACHE_PREFIX = 'wordtrail-assets-';
const CACHE = CACHE_PREFIX + VERSION;
const ASSETS = ["/assets/index-D5Ove13S.css","/assets/index-DWytfQXA.js","/icon.svg","/icons/apple-touch-icon.png","/icons/icon-192.png","/icons/icon-512.png","/icons/maskable-512.png","/index.html","/manifest.webmanifest"];
const ASSET_SET = new Set(ASSETS);

self.addEventListener('install', (event) => {
  // Do not skipWaiting here: an update must not replace a learner's active app.
  event.waitUntil(caches.open(CACHE).then((cache) =>
    cache.addAll(ASSETS.map((url) => new Request(url, { cache: 'reload' })))
  ));
});

self.addEventListener('activate', (event) => {
  event.waitUntil((async () => {
    const keys = await caches.keys();
    await Promise.all(keys.filter((key) => key.startsWith(CACHE_PREFIX) && key !== CACHE)
      .map((key) => caches.delete(key)));
    await self.clients.claim();
  })());
});

self.addEventListener('message', (event) => {
  // This is only used when a future UI explicitly offers an update button.
  if (event.data?.type === 'SKIP_WAITING') self.skipWaiting();
  if (event.data?.type === 'GET_OFFLINE_STATUS' && event.ports[0]) {
    event.waitUntil(caches.open(CACHE).then(async (cache) => {
      const shell = await cache.match('/index.html');
      event.ports[0].postMessage({ ready: Boolean(shell), version: VERSION });
    }));
  }
});

async function navigate(request) {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4500);
  try {
    const response = await fetch(request, { signal: controller.signal });
    if (response.ok) return response;
  } catch (_) {
    // Network unavailable: use the shell from this exact cached build.
  } finally {
    clearTimeout(timeout);
  }
  const cache = await caches.open(CACHE);
  return (await cache.match('/index.html')) || new Response(
    'Wordtrail is not cached yet. Connect once to finish setup.',
    { status: 503, headers: { 'Content-Type': 'text/plain; charset=utf-8' } }
  );
}

self.addEventListener('fetch', (event) => {
  const request = event.request;
  const url = new URL(request.url);
  if (request.method !== 'GET' || url.origin !== self.location.origin) return;
  if (request.mode === 'navigate') {
    event.respondWith(navigate(request));
    return;
  }
  // Only cache known app assets. Backups, arbitrary URLs and private responses
  // cannot accidentally become part of the app's persistent asset cache.
  if (!ASSET_SET.has(url.pathname)) return;
  event.respondWith((async () => {
    const cache = await caches.open(CACHE);
    const cached = await cache.match(url.pathname);
    if (cached) return cached;
    const response = await fetch(request);
    if (response.ok && response.type === 'basic') await cache.put(url.pathname, response.clone());
    return response;
  })());
});
